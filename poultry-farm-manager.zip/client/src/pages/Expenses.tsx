import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { DollarSign, Plus, Pill, Users, Zap, MoreHorizontal, Wheat } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { format } from "date-fns";

type ExpenseCategory = "feed" | "medication" | "labor" | "utilities" | "miscellaneous";

const CATEGORIES: { value: ExpenseCategory; label: string; icon: React.ElementType; color: string; badgeClass: string }[] = [
  { value: "feed", label: "Feed", icon: Wheat, color: "oklch(0.72 0.15 80)", badgeClass: "bg-amber-50 text-amber-700 border-amber-200" },
  { value: "medication", label: "Medication", icon: Pill, color: "oklch(0.60 0.15 200)", badgeClass: "bg-blue-50 text-blue-700 border-blue-200" },
  { value: "labor", label: "Labor", icon: Users, color: "oklch(0.40 0.13 155)", badgeClass: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  { value: "utilities", label: "Utilities", icon: Zap, color: "oklch(0.62 0.16 300)", badgeClass: "bg-purple-50 text-purple-700 border-purple-200" },
  { value: "miscellaneous", label: "Miscellaneous", icon: MoreHorizontal, color: "oklch(0.55 0.04 150)", badgeClass: "bg-muted text-muted-foreground" },
];

const PIE_COLORS = CATEGORIES.map(c => c.color);

function AddExpenseDialog({ flocks, onSuccess }: { flocks: { id: number; name: string }[]; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    flockId: "",
    expenseDate: new Date().toISOString().split("T")[0],
    category: "feed" as ExpenseCategory,
    description: "",
    amount: "",
    notes: "",
  });

  const createExpense = trpc.expense.create.useMutation({
    onSuccess: () => {
      toast.success("Expense recorded");
      setOpen(false);
      setForm({ flockId: "", expenseDate: new Date().toISOString().split("T")[0], category: "feed", description: "", amount: "", notes: "" });
      onSuccess();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description || !form.amount) {
      toast.error("Please fill in all required fields");
      return;
    }
    createExpense.mutate({
      flockId: form.flockId ? parseInt(form.flockId) : undefined,
      expenseDate: form.expenseDate,
      category: form.category,
      description: form.description,
      amount: parseFloat(form.amount),
      notes: form.notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2"><Plus className="h-4 w-4" />Add Expense</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Record Expense</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Category <span className="text-destructive">*</span></Label>
              <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v as ExpenseCategory }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(c => (
                    <SelectItem key={c.value} value={c.value}>
                      <div className="flex items-center gap-2">
                        <c.icon className="h-3.5 w-3.5" />
                        {c.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={form.expenseDate} onChange={e => setForm(f => ({ ...f, expenseDate: e.target.value }))} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Description <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. Veterinary visit" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Amount ($) <span className="text-destructive">*</span></Label>
              <Input type="number" min="0" step="0.01" placeholder="e.g. 150.00" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Assign to Flock</Label>
            <Select value={form.flockId} onValueChange={v => setForm(f => ({ ...f, flockId: v }))}>
              <SelectTrigger><SelectValue placeholder="General (not flock-specific)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                {flocks.map(fl => <SelectItem key={fl.id} value={String(fl.id)}>{fl.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createExpense.isPending}>{createExpense.isPending ? "Saving..." : "Record Expense"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Expenses() {
  const utils = trpc.useUtils();
  const { data: expenses, isLoading } = trpc.expense.list.useQuery();
  const { data: byCategory } = trpc.expense.byCategory.useQuery();
  const { data: flocks } = trpc.flock.list.useQuery();

  const totalExpenses = (expenses ?? []).reduce((s, e) => s + Number(e.amount), 0);

  const pieData = (byCategory ?? []).map(c => {
    const cat = CATEGORIES.find(x => x.value === c.category);
    return { name: cat?.label ?? c.category, value: Number(c.total ?? 0), color: cat?.color ?? "#ccc" };
  });

  const categoryTotals = CATEGORIES.map(cat => {
    const total = (expenses ?? []).filter(e => e.category === cat.value).reduce((s, e) => s + Number(e.amount), 0);
    return { ...cat, total };
  });

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Expense Tracking</h1>
          <p className="text-sm text-muted-foreground mt-1">Monitor all farm expenditures by category</p>
        </div>
        <AddExpenseDialog flocks={(flocks ?? []).filter(f => f.status === "active")} onSuccess={() => { utils.expense.list.invalidate(); utils.expense.byCategory.invalidate(); }} />
      </div>

      {/* Total */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <Card className="border border-border/60 shadow-sm col-span-2 sm:col-span-1">
          <CardContent className="p-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Total Expenses</p>
            <p className="text-3xl font-bold text-destructive mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              ${totalExpenses.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </CardContent>
        </Card>
        {categoryTotals.filter(c => c.total > 0).slice(0, 2).map(cat => (
          <Card key={cat.value} className="border border-border/60 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <cat.icon className="h-3.5 w-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{cat.label}</p>
              </div>
              <p className="text-2xl font-bold mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                ${cat.total.toFixed(2)}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Category Breakdown Chart */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Expenses by Category</CardTitle>
          </CardHeader>
          <CardContent>
            {pieData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No expense data yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: "8px", fontSize: "12px" }}
                    formatter={(v: number) => [`$${v.toFixed(2)}`, ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Category Summary */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Category Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {categoryTotals.map(cat => (
                <div key={cat.value} className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: cat.color + "20" }}>
                    <cat.icon className="h-4 w-4" style={{ color: cat.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{cat.label}</span>
                      <span className="text-sm font-semibold">${cat.total.toFixed(2)}</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: totalExpenses > 0 ? `${(cat.total / totalExpenses) * 100}%` : "0%",
                          backgroundColor: cat.color,
                        }}
                      />
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground w-10 text-right">
                    {totalExpenses > 0 ? `${((cat.total / totalExpenses) * 100).toFixed(0)}%` : "0%"}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Expenses Table */}
      <Card className="border border-border/60 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-semibold">All Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : !expenses || expenses.length === 0 ? (
            <div className="py-12 flex flex-col items-center gap-3">
              <DollarSign className="h-10 w-10 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No expenses recorded yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60">
                    {["Date", "Category", "Description", "Amount", "Flock"].map(h => (
                      <th key={h} className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {expenses.map((exp) => {
                    const cat = CATEGORIES.find(c => c.value === exp.category);
                    const flock = flocks?.find(f => f.id === exp.flockId);
                    return (
                      <tr key={exp.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                        <td className="py-2.5 px-3 font-medium whitespace-nowrap">{format(new Date(exp.expenseDate), "MMM d, yyyy")}</td>
                        <td className="py-2.5 px-3">
                          {cat && (
                            <Badge variant="outline" className={`text-[10px] ${cat.badgeClass}`}>
                              <cat.icon className="h-2.5 w-2.5 mr-1" />
                              {cat.label}
                            </Badge>
                          )}
                        </td>
                        <td className="py-2.5 px-3">{exp.description}</td>
                        <td className="py-2.5 px-3 font-semibold text-destructive">${Number(exp.amount).toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{flock?.name ?? "General"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
