import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Wheat, Plus, ShoppingBag, Calculator } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

function AddPurchaseDialog({ flocks, onSuccess }: { flocks: { id: number; name: string }[]; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    flockId: "",
    purchaseDate: new Date().toISOString().split("T")[0],
    feedType: "",
    quantityKg: "",
    costPerKg: "",
    supplier: "",
    notes: "",
  });

  const createPurchase = trpc.feed.createPurchase.useMutation({
    onSuccess: () => {
      toast.success("Feed purchase recorded");
      setOpen(false);
      setForm({ flockId: "", purchaseDate: new Date().toISOString().split("T")[0], feedType: "", quantityKg: "", costPerKg: "", supplier: "", notes: "" });
      onSuccess();
    },
    onError: (err) => toast.error(err.message),
  });

  const totalCost = form.quantityKg && form.costPerKg
    ? (parseFloat(form.quantityKg) * parseFloat(form.costPerKg)).toFixed(2)
    : "0.00";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.feedType || !form.quantityKg || !form.costPerKg) {
      toast.error("Please fill in all required fields");
      return;
    }
    createPurchase.mutate({
      flockId: form.flockId ? parseInt(form.flockId) : undefined,
      purchaseDate: form.purchaseDate,
      feedType: form.feedType,
      quantityKg: parseFloat(form.quantityKg),
      costPerKg: parseFloat(form.costPerKg),
      supplier: form.supplier || undefined,
      notes: form.notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2"><Plus className="h-4 w-4" />Record Purchase</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Record Feed Purchase</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Feed Type <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. Layer Mash" value={form.feedType} onChange={e => setForm(f => ({ ...f, feedType: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Purchase Date</Label>
              <Input type="date" value={form.purchaseDate} onChange={e => setForm(f => ({ ...f, purchaseDate: e.target.value }))} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Quantity (kg) <span className="text-destructive">*</span></Label>
              <Input type="number" min="0" step="0.1" placeholder="e.g. 100" value={form.quantityKg} onChange={e => setForm(f => ({ ...f, quantityKg: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Cost per kg ($) <span className="text-destructive">*</span></Label>
              <Input type="number" min="0" step="0.01" placeholder="e.g. 0.50" value={form.costPerKg} onChange={e => setForm(f => ({ ...f, costPerKg: e.target.value }))} />
            </div>
          </div>
          {form.quantityKg && form.costPerKg && (
            <div className="rounded-lg bg-primary/5 border border-primary/20 px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Cost</span>
              <span className="text-lg font-bold text-primary">${totalCost}</span>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Assign to Flock</Label>
              <Select value={form.flockId} onValueChange={v => setForm(f => ({ ...f, flockId: v }))}>
                <SelectTrigger><SelectValue placeholder="All flocks" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All flocks</SelectItem>
                  {flocks.map(fl => <SelectItem key={fl.id} value={String(fl.id)}>{fl.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Supplier</Label>
              <Input placeholder="e.g. AgriSupply Co." value={form.supplier} onChange={e => setForm(f => ({ ...f, supplier: e.target.value }))} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createPurchase.isPending}>{createPurchase.isPending ? "Saving..." : "Record Purchase"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Feed() {
  const utils = trpc.useUtils();
  const { data: purchases, isLoading: purchasesLoading } = trpc.feed.purchases.useQuery();
  const { data: flocks } = trpc.flock.list.useQuery();
  const [selectedFlockId, setSelectedFlockId] = useState<number | null>(null);

  const activeFlocks = (flocks ?? []).filter(f => f.status === "active");
  const selectedFlock = activeFlocks.find(f => f.id === selectedFlockId);

  const { data: fcrData, isLoading: fcrLoading } = trpc.feed.fcrAndCostPerBird.useQuery(
    { flockId: selectedFlockId! },
    { enabled: !!selectedFlockId }
  );

  const totalFeedCost = (purchases ?? []).reduce((s, p) => s + Number(p.totalCost), 0);
  const totalFeedKg = (purchases ?? []).reduce((s, p) => s + Number(p.quantityKg), 0);

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Feed Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Track feed purchases, consumption, and efficiency metrics</p>
        </div>
        <AddPurchaseDialog flocks={activeFlocks} onSuccess={() => utils.feed.purchases.invalidate()} />
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {[
          { label: "Total Feed Purchased", value: `${totalFeedKg.toFixed(1)} kg`, color: "text-amber-700" },
          { label: "Total Feed Cost", value: `$${totalFeedCost.toFixed(2)}`, color: "text-primary" },
          { label: "Total Purchases", value: purchases?.length ?? 0, color: "text-foreground" },
        ].map((stat) => (
          <Card key={stat.label} className="border border-border/60 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
              <p className={`text-2xl font-bold mt-1 ${stat.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* FCR Calculator */}
      <Card className="border border-border/60 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Calculator className="h-4 w-4 text-primary" />
            Feed Conversion Ratio (FCR) & Cost per Bird
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <div className="w-full sm:w-64">
              <Label className="mb-1.5 block text-xs text-muted-foreground">Select Flock</Label>
              <Select value={selectedFlockId ? String(selectedFlockId) : ""} onValueChange={v => setSelectedFlockId(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a flock..." />
                </SelectTrigger>
                <SelectContent>
                  {activeFlocks.map(fl => <SelectItem key={fl.id} value={String(fl.id)}>{fl.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {selectedFlockId && (
              fcrLoading ? (
                <div className="flex gap-4">
                  <Skeleton className="h-20 w-36" />
                  <Skeleton className="h-20 w-36" />
                  <Skeleton className="h-20 w-36" />
                </div>
              ) : fcrData ? (
                <div className="flex flex-wrap gap-4">
                  <div className="rounded-xl border border-primary/20 bg-primary/5 px-5 py-4 min-w-[130px]">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">FCR</p>
                    <p className="text-2xl font-bold text-primary mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{fcrData.fcr}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Feed Conversion Ratio</p>
                  </div>
                  <div className="rounded-xl border border-amber-200 bg-amber-50 px-5 py-4 min-w-[130px]">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Cost per Bird</p>
                    <p className="text-2xl font-bold text-amber-700 mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>${fcrData.costPerBird}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Feed cost per bird</p>
                  </div>
                  <div className="rounded-xl border border-border/60 bg-muted/30 px-5 py-4 min-w-[130px]">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Feed Used</p>
                    <p className="text-2xl font-bold mt-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{Number(fcrData.totalFeedUsed).toFixed(1)} kg</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Total consumed</p>
                  </div>
                </div>
              ) : null
            )}
          </div>
          {!selectedFlockId && (
            <p className="text-sm text-muted-foreground mt-3">Select a flock above to calculate its Feed Conversion Ratio (FCR) and cost per bird.</p>
          )}
        </CardContent>
      </Card>

      {/* Purchases Table */}
      <Card className="border border-border/60 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <ShoppingBag className="h-4 w-4 text-primary" />
            Feed Purchase History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {purchasesLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : !purchases || purchases.length === 0 ? (
            <div className="py-12 flex flex-col items-center gap-3">
              <Wheat className="h-10 w-10 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No feed purchases recorded yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60">
                    {["Date", "Feed Type", "Quantity (kg)", "Cost/kg", "Total Cost", "Flock", "Supplier"].map(h => (
                      <th key={h} className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {purchases.map((p) => {
                    const flock = flocks?.find(f => f.id === p.flockId);
                    return (
                      <tr key={p.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                        <td className="py-2.5 px-3 font-medium whitespace-nowrap">{format(new Date(p.purchaseDate), "MMM d, yyyy")}</td>
                        <td className="py-2.5 px-3">
                          <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">{p.feedType}</Badge>
                        </td>
                        <td className="py-2.5 px-3 text-right">{Number(p.quantityKg).toFixed(1)}</td>
                        <td className="py-2.5 px-3 text-right">${Number(p.costPerKg).toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-right font-semibold text-primary">${Number(p.totalCost).toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{flock?.name ?? "—"}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{p.supplier ?? "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
