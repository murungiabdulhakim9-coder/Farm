import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Bird, Plus, Calendar, Package, ChevronRight, CheckCircle2, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

function AddFlockDialog({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    breed: "",
    type: "layer" as "layer" | "broiler",
    arrivalDate: new Date().toISOString().split("T")[0],
    initialCount: "",
    supplier: "",
    notes: "",
  });

  const createFlock = trpc.flock.create.useMutation({
    onSuccess: () => {
      toast.success("Flock added successfully");
      setOpen(false);
      setForm({ name: "", breed: "", type: "layer", arrivalDate: new Date().toISOString().split("T")[0], initialCount: "", supplier: "", notes: "" });
      onSuccess();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.breed || !form.initialCount) {
      toast.error("Please fill in all required fields");
      return;
    }
    createFlock.mutate({
      name: form.name,
      breed: form.breed,
      type: form.type,
      arrivalDate: form.arrivalDate,
      initialCount: parseInt(form.initialCount),
      supplier: form.supplier || undefined,
      notes: form.notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Add Flock
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Add New Flock</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="name">Flock Name <span className="text-destructive">*</span></Label>
              <Input
                id="name"
                placeholder="e.g. Batch A - April"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="type">Type <span className="text-destructive">*</span></Label>
              <Select value={form.type} onValueChange={(v) => setForm(f => ({ ...f, type: v as "layer" | "broiler" }))}>
                <SelectTrigger id="type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="layer">Layer</SelectItem>
                  <SelectItem value="broiler">Broiler</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="breed">Breed <span className="text-destructive">*</span></Label>
              <Input
                id="breed"
                placeholder="e.g. ISA Brown"
                value={form.breed}
                onChange={e => setForm(f => ({ ...f, breed: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="initialCount">Initial Bird Count <span className="text-destructive">*</span></Label>
              <Input
                id="initialCount"
                type="number"
                min="1"
                placeholder="e.g. 500"
                value={form.initialCount}
                onChange={e => setForm(f => ({ ...f, initialCount: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="arrivalDate">Arrival Date <span className="text-destructive">*</span></Label>
              <Input
                id="arrivalDate"
                type="date"
                value={form.arrivalDate}
                onChange={e => setForm(f => ({ ...f, arrivalDate: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="supplier">Supplier</Label>
              <Input
                id="supplier"
                placeholder="e.g. Green Valley Farm"
                value={form.supplier}
                onChange={e => setForm(f => ({ ...f, supplier: e.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Any additional notes..."
              rows={2}
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createFlock.isPending}>
              {createFlock.isPending ? "Adding..." : "Add Flock"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Flocks() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const { data: flocks, isLoading } = trpc.flock.list.useQuery();

  const activeFlocks = flocks?.filter(f => f.status === "active") ?? [];
  const closedFlocks = flocks?.filter(f => f.status === "closed") ?? [];

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Flock Management</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your poultry batches and track their performance
          </p>
        </div>
        <AddFlockDialog onSuccess={() => utils.flock.list.invalidate()} />
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Flocks", value: flocks?.length ?? 0, color: "text-foreground" },
          { label: "Active Flocks", value: activeFlocks.length, color: "text-emerald-600" },
          { label: "Closed Flocks", value: closedFlocks.length, color: "text-muted-foreground" },
          { label: "Total Birds", value: (flocks ?? []).reduce((s, f) => s + f.initialCount, 0).toLocaleString(), color: "text-primary" },
        ].map((stat) => (
          <Card key={stat.label} className="border border-border/60 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
              <p className={`text-2xl font-bold mt-1 ${stat.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Active Flocks */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">Active Flocks</h2>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-40 rounded-xl" />)}
          </div>
        ) : activeFlocks.length === 0 ? (
          <Card className="border border-dashed border-border/60">
            <CardContent className="p-12 flex flex-col items-center gap-3">
              <Bird className="h-10 w-10 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No active flocks. Add your first flock to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {activeFlocks.map((flock) => (
              <Card
                key={flock.id}
                className="border border-border/60 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer group"
                onClick={() => setLocation(`/flocks/${flock.id}`)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Bird className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{flock.name}</h3>
                        <p className="text-xs text-muted-foreground">{flock.breed}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={`text-[10px] ${flock.type === "layer" ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                        {flock.type === "layer" ? "Layer" : "Broiler"}
                      </Badge>
                      <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-primary transition-colors" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Package className="h-3.5 w-3.5" />
                      <span>{flock.initialCount.toLocaleString()} birds</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{format(new Date(flock.arrivalDate), "MMM d, yyyy")}</span>
                    </div>
                    {flock.supplier && (
                      <div className="col-span-2 text-xs text-muted-foreground truncate">
                        Supplier: {flock.supplier}
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-border/40 flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                    <span className="text-xs font-medium text-emerald-600">Active</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Closed Flocks */}
      {closedFlocks.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">Closed Flocks</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {closedFlocks.map((flock) => (
              <Card
                key={flock.id}
                className="border border-border/40 shadow-sm opacity-70 hover:opacity-90 transition-opacity cursor-pointer"
                onClick={() => setLocation(`/flocks/${flock.id}`)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
                        <Bird className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{flock.name}</h3>
                        <p className="text-xs text-muted-foreground">{flock.breed}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px] bg-muted text-muted-foreground">
                      {flock.type === "layer" ? "Layer" : "Broiler"}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border/40">
                    <XCircle className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Closed</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
