import { trpc } from "@/lib/trpc";
import { BarChart3, TrendingUp, TrendingDown, DollarSign, Wheat, Skull, Bird } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  AreaChart, Area, PieChart, Pie, Cell, LineChart, Line,
} from "recharts";

const EXPENSE_COLORS: Record<string, string> = {
  feed: "oklch(0.72 0.15 80)",
  medication: "oklch(0.60 0.15 200)",
  labor: "oklch(0.40 0.13 155)",
  utilities: "oklch(0.62 0.16 300)",
  miscellaneous: "oklch(0.55 0.04 150)",
};

const EXPENSE_LABELS: Record<string, string> = {
  feed: "Feed",
  medication: "Medication",
  labor: "Labor",
  utilities: "Utilities",
  miscellaneous: "Miscellaneous",
};

export default function Reports() {
  const { data: profitLoss, isLoading: plLoading } = trpc.reports.profitLoss.useQuery();
  const { data: mortalityRates, isLoading: mortLoading } = trpc.reports.flockMortalityRates.useQuery();
  const { data: feedUsage, isLoading: feedLoading } = trpc.reports.feedUsagePerFlock.useQuery();
  const { data: mortalityTrend, isLoading: trendLoading } = trpc.reports.mortalityLast30Days.useQuery();
  const { data: monthlyExpenses, isLoading: expLoading } = trpc.reports.monthlyExpenses.useQuery({ months: 6 });
  const { data: monthlyRevenue, isLoading: revLoading } = trpc.reports.monthlyRevenue.useQuery({ months: 6 });

  const isProfitable = (profitLoss?.profitLoss ?? 0) >= 0;

  // Build monthly P&L chart data
  const monthlyMap: Record<string, { month: string; revenue: number; expenses: number; profit: number }> = {};
  const allMonths = new Set<string>();

  // Collect revenue months
  (monthlyRevenue?.eggs ?? []).forEach(e => allMonths.add(e.month));
  (monthlyRevenue?.birds ?? []).forEach(b => allMonths.add(b.month));
  (monthlyExpenses ?? []).forEach(e => { if (e.month) allMonths.add(e.month); });

  allMonths.forEach(month => {
    monthlyMap[month] = { month, revenue: 0, expenses: 0, profit: 0 };
  });
  (monthlyRevenue?.eggs ?? []).forEach(e => { if (monthlyMap[e.month]) monthlyMap[e.month].revenue += Number(e.total ?? 0); });
  (monthlyRevenue?.birds ?? []).forEach(b => { if (monthlyMap[b.month]) monthlyMap[b.month].revenue += Number(b.total ?? 0); });
  (monthlyExpenses ?? []).forEach(e => { if (e.month && monthlyMap[e.month]) monthlyMap[e.month].expenses += Number(e.total ?? 0); });
  Object.values(monthlyMap).forEach(m => { m.profit = m.revenue - m.expenses; });
  const plChartData = Object.values(monthlyMap).sort((a, b) => a.month.localeCompare(b.month));

  // Mortality trend
  const mortalityTrendData = (mortalityTrend ?? []).map(d => ({
    date: d.date.slice(5), // MM-DD
    mortality: Number(d.total ?? 0),
  }));

  // Expense pie data
  const expPieData = (profitLoss?.expensesByCategory ?? []).map(c => ({
    name: EXPENSE_LABELS[c.category] ?? c.category,
    value: Number(c.total ?? 0),
    color: EXPENSE_COLORS[c.category] ?? "#ccc",
  }));

  // Feed usage per flock
  const feedChartData = (feedUsage ?? []).map(f => ({
    name: f.flockName.length > 12 ? f.flockName.slice(0, 12) + "…" : f.flockName,
    feedUsed: Number(f.totalFeedUsed),
    fcr: f.fcr,
  }));

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground mt-1">Comprehensive analytics and performance metrics</p>
        </div>
      </div>

      {/* Profit/Loss Summary */}
      <Card className="border border-border/60 shadow-sm overflow-hidden">
        <div className={`h-1 w-full ${isProfitable ? "bg-emerald-400" : "bg-red-400"}`} />
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-primary" />
            Profit/Loss Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          {plLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-20" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: "Total Revenue", value: `$${Number(profitLoss?.totalRevenue ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}`, color: "text-primary", bg: "bg-primary/5 border-primary/20" },
                { label: "Egg Sales Revenue", value: `$${Number(profitLoss?.totalEggRevenue ?? 0).toFixed(2)}`, color: "text-amber-700", bg: "bg-amber-50 border-amber-200" },
                { label: "Bird Sales Revenue", value: `$${Number(profitLoss?.totalBirdRevenue ?? 0).toFixed(2)}`, color: "text-blue-700", bg: "bg-blue-50 border-blue-200" },
                {
                  label: "Total Expenses",
                  value: `$${Number(profitLoss?.totalExpenses ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}`,
                  color: "text-destructive",
                  bg: "bg-red-50 border-red-200",
                },
              ].map(stat => (
                <div key={stat.label} className={`rounded-xl border p-4 ${stat.bg}`}>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
                  <p className={`text-xl font-bold mt-1 ${stat.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{stat.value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Net P&L */}
          {!plLoading && (
            <div className={`mt-4 rounded-xl border p-5 flex items-center justify-between ${isProfitable ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"}`}>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Net Profit/Loss</p>
                <p className={`text-3xl font-bold mt-1 ${isProfitable ? "text-emerald-700" : "text-red-700"}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  {isProfitable ? "+" : ""}${Number(profitLoss?.profitLoss ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
              <div className={`h-14 w-14 rounded-2xl flex items-center justify-center ${isProfitable ? "bg-emerald-100" : "bg-red-100"}`}>
                {isProfitable ? (
                  <TrendingUp className="h-7 w-7 text-emerald-600" />
                ) : (
                  <TrendingDown className="h-7 w-7 text-red-600" />
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Monthly P&L Chart */}
      <Card className="border border-border/60 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-semibold">Monthly Revenue vs Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          {(revLoading || expLoading) ? (
            <Skeleton className="h-56 w-full" />
          ) : plChartData.length === 0 ? (
            <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">
              No financial data available yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={plChartData} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `$${v}`} />
                <Tooltip
                  contentStyle={{ borderRadius: "8px", fontSize: "12px" }}
                  formatter={(v: number) => [`$${v.toFixed(2)}`, ""]}
                />
                <Legend wrapperStyle={{ fontSize: "12px" }} />
                <Bar dataKey="revenue" name="Revenue" fill="oklch(0.40 0.13 155)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expenses" name="Expenses" fill="oklch(0.55 0.22 25)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Mortality Rate per Flock */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Skull className="h-4 w-4 text-red-500" />
              Mortality Rate per Flock
            </CardTitle>
          </CardHeader>
          <CardContent>
            {mortLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : !mortalityRates || mortalityRates.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No flock data available.
              </div>
            ) : (
              <div className="space-y-3">
                {mortalityRates.map(flock => (
                  <div key={flock.flockId} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Bird className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-sm font-medium">{flock.flockName}</span>
                        <span className="text-xs text-muted-foreground">({flock.breed})</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">{flock.totalMortality} birds</span>
                        <Badge
                          variant="outline"
                          className={`text-[10px] ${flock.mortalityRate > 5 ? "bg-red-50 text-red-700 border-red-200" : flock.mortalityRate > 2 ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-emerald-50 text-emerald-700 border-emerald-200"}`}
                        >
                          {flock.mortalityRate.toFixed(2)}%
                        </Badge>
                      </div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${Math.min(flock.mortalityRate * 5, 100)}%`,
                          backgroundColor: flock.mortalityRate > 5 ? "oklch(0.55 0.22 25)" : flock.mortalityRate > 2 ? "oklch(0.72 0.15 80)" : "oklch(0.40 0.13 155)",
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expense Breakdown Pie */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Total Expenses Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {plLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : expPieData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No expense data available.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={expPieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                    {expPieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: "8px", fontSize: "12px" }}
                    formatter={(v: number) => [`$${v.toFixed(2)}`, ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Feed Usage per Flock */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Wheat className="h-4 w-4 text-amber-600" />
              Feed Usage per Flock
            </CardTitle>
          </CardHeader>
          <CardContent>
            {feedLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : !feedChartData || feedChartData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No feed usage data available.
              </div>
            ) : (
              <>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={feedChartData} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit=" kg" />
                    <Tooltip
                      contentStyle={{ borderRadius: "8px", fontSize: "12px" }}
                      formatter={(v: number) => [`${v.toFixed(1)} kg`, "Feed Used"]}
                    />
                    <Bar dataKey="feedUsed" name="Feed Used (kg)" fill="oklch(0.72 0.15 80)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-2">
                  {(feedUsage ?? []).map(f => (
                    <div key={f.flockId} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground truncate max-w-[150px]">{f.flockName}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-xs text-muted-foreground">{Number(f.totalFeedUsed).toFixed(1)} kg</span>
                        <Badge variant="outline" className="text-[10px] bg-primary/5 text-primary border-primary/20">
                          FCR: {f.fcr.toFixed(3)}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* 30-Day Mortality Trend */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Skull className="h-4 w-4 text-red-500" />
              Mortality Trend — Last 30 Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            {trendLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : mortalityTrendData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No mortality data for the last 30 days.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={mortalityTrendData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="mortGradReport" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                  <Area type="monotone" dataKey="mortality" name="Mortality" stroke="oklch(0.55 0.22 25)" strokeWidth={2} fill="url(#mortGradReport)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
