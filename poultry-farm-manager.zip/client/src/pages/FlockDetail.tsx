import { trpc } from "@/lib/trpc";
import { useParams, useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft, Bird, Calendar, Package, Skull, Wheat,
  Egg, Weight, CheckCircle2, XCircle, ClipboardList, TrendingDown,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

export default function FlockDetail() {
  const params = useParams<{ id: string }>();
  const flockId = parseInt(params.id ?? "0");
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: flock, isLoading: flockLoading } = trpc.flock.get.useQuery({ id: flockId });
  const { data: dailyRecords, isLoading: recordsLoading } = trpc.dailyRecords.byFlock.useQuery({ flockId, limit: 30 });

  const [form, setForm] = useState({
    recordDate: new Date().toISOString().split("T")[0],
    mortality: "0",
    feedUsed: "0",
    eggsCollected: "0",
    brokenEggs: "0",
    averageWeight: "",
    notes: "",
  });

  const upsertRecord = trpc.dailyRecords.upsert.useMutation({
    onSuccess: () => {
      toast.success("Daily record saved");
      utils.dailyRecords.byFlock.invalidate({ flockId });
      utils.flock.get.invalidate({ id: flockId });
      utils.dashboard.summary.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const updateStatus = trpc.flock.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Flock status updated");
      utils.flock.get.invalidate({ id: flockId });
      utils.flock.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: Parameters<typeof upsertRecord.mutate>[0] = {
      flockId,
      recordDate: form.recordDate,
      mortality: parseInt(form.mortality) || 0,
      feedUsed: parseFloat(form.feedUsed) || 0,
      notes: form.notes || undefined,
    };
    if (flock?.type === "layer") {
      payload.eggsCollected = parseInt(form.eggsCollected) || 0;
      payload.brokenEggs = parseInt(form.brokenEggs) || 0;
    } else {
      if (form.averageWeight) payload.averageWeight = parseFloat(form.averageWeight);
    }
    upsertRecord.mutate(payload);
  };

  const mortalityChartData = (dailyRecords ?? [])
    .slice()
    .reverse()
    .map(r => ({
      date: format(new Date(r.recordDate), "MMM d"),
      mortality: r.mortality,
      feedUsed: Number(r.feedUsed),
      eggs: r.eggsCollected ?? 0,
    }));

  if (flockLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!flock) {
    return (
      <div className="flex flex-col items-center gap-4 py-20">
        <Bird className="h-12 w-12 text-muted-foreground/40" />
        <p className="text-muted-foreground">Flock not found</p>
        <Button variant="outline" onClick={() => setLocation("/flocks")}>Back to Flocks</Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/flocks")} className="mt-0.5 shrink-0">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold text-foreground">{flock.name}</h1>
            <Badge variant="outline" className={`text-xs ${flock.type === "layer" ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
              {flock.type === "layer" ? "Layer" : "Broiler"}
            </Badge>
            <Badge variant="outline" className={`text-xs ${flock.status === "active" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-muted text-muted-foreground"}`}>
              {flock.status === "active" ? "Active" : "Closed"}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">{flock.breed}</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => updateStatus.mutate({ id: flockId, status: flock.status === "active" ? "closed" : "active" })}
          disabled={updateStatus.isPending}
          className={flock.status === "active" ? "text-destructive border-destructive/30 hover:bg-destructive/5" : "text-emerald-600 border-emerald-200 hover:bg-emerald-50"}
        >
          {flock.status === "active" ? <><XCircle className="h-3.5 w-3.5 mr-1.5" />Close Flock</> : <><CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />Reactivate</>}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Initial Count", value: flock.initialCount.toLocaleString(), icon: Package, color: "bg-blue-100 text-blue-700" },
          { label: "Current Count", value: flock.currentCount.toLocaleString(), icon: Bird, color: "bg-emerald-100 text-emerald-700" },
          { label: "Total Mortality", value: flock.totalMortality.toLocaleString(), icon: Skull, color: "bg-red-100 text-red-600" },
          { label: "Mortality Rate", value: `${flock.mortalityRate}%`, icon: TrendingDown, color: "bg-amber-100 text-amber-700" },
        ].map((stat) => (
          <Card key={stat.label} className="border border-border/60 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${stat.color}`}>
                  <stat.icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-lg font-bold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{stat.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Flock Info */}
      <Card className="border border-border/60 shadow-sm">
        <CardContent className="p-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Arrival Date</p>
              <div className="flex items-center gap-1.5 font-medium">
                <Calendar className="h-3.5 w-3.5 text-primary" />
                {format(new Date(flock.arrivalDate), "MMM d, yyyy")}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Total Feed Used</p>
              <div className="flex items-center gap-1.5 font-medium">
                <Wheat className="h-3.5 w-3.5 text-amber-600" />
                {Number(flock.totalFeedUsed).toFixed(1)} kg
              </div>
            </div>
            {flock.supplier && (
              <div>
                <p className="text-xs text-muted-foreground mb-1">Supplier</p>
                <p className="font-medium">{flock.supplier}</p>
              </div>
            )}
            {flock.notes && (
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Notes</p>
                <p className="text-sm">{flock.notes}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Daily Record Entry */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-primary" />
              Daily Record Entry
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="recordDate">Date</Label>
                <Input
                  id="recordDate"
                  type="date"
                  value={form.recordDate}
                  onChange={e => setForm(f => ({ ...f, recordDate: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="mortality" className="flex items-center gap-1.5">
                    <Skull className="h-3.5 w-3.5 text-red-500" />
                    Mortality
                  </Label>
                  <Input
                    id="mortality"
                    type="number"
                    min="0"
                    value={form.mortality}
                    onChange={e => setForm(f => ({ ...f, mortality: e.target.value }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="feedUsed" className="flex items-center gap-1.5">
                    <Wheat className="h-3.5 w-3.5 text-amber-600" />
                    Feed Used (kg)
                  </Label>
                  <Input
                    id="feedUsed"
                    type="number"
                    min="0"
                    step="0.1"
                    value={form.feedUsed}
                    onChange={e => setForm(f => ({ ...f, feedUsed: e.target.value }))}
                  />
                </div>
              </div>

              {flock.type === "layer" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="eggsCollected" className="flex items-center gap-1.5">
                      <Egg className="h-3.5 w-3.5 text-amber-500" />
                      Eggs Collected
                    </Label>
                    <Input
                      id="eggsCollected"
                      type="number"
                      min="0"
                      value={form.eggsCollected}
                      onChange={e => setForm(f => ({ ...f, eggsCollected: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="brokenEggs">Broken Eggs</Label>
                    <Input
                      id="brokenEggs"
                      type="number"
                      min="0"
                      value={form.brokenEggs}
                      onChange={e => setForm(f => ({ ...f, brokenEggs: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              {flock.type === "broiler" && (
                <div className="space-y-1.5">
                  <Label htmlFor="averageWeight" className="flex items-center gap-1.5">
                    <Weight className="h-3.5 w-3.5 text-blue-500" />
                    Average Weight (kg)
                  </Label>
                  <Input
                    id="averageWeight"
                    type="number"
                    min="0"
                    step="0.001"
                    placeholder="e.g. 1.250"
                    value={form.averageWeight}
                    onChange={e => setForm(f => ({ ...f, averageWeight: e.target.value }))}
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  rows={2}
                  placeholder="Any observations..."
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                />
              </div>

              <Button type="submit" className="w-full" disabled={upsertRecord.isPending}>
                {upsertRecord.isPending ? "Saving..." : "Save Daily Record"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Chart */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Mortality Trend</CardTitle>
          </CardHeader>
          <CardContent>
            {recordsLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : mortalityChartData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No records yet. Start adding daily entries.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={mortalityChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="mortGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
                  <Area type="monotone" dataKey="mortality" stroke="oklch(0.55 0.22 25)" strokeWidth={2} fill="url(#mortGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Records Table */}
      {dailyRecords && dailyRecords.length > 0 && (
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Recent Daily Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60">
                    <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Date</th>
                    <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Mortality</th>
                    <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Feed Used (kg)</th>
                    {flock.type === "layer" && (
                      <>
                        <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Eggs Collected</th>
                        <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Broken Eggs</th>
                      </>
                    )}
                    {flock.type === "broiler" && (
                      <th className="text-right py-2 px-3 text-xs font-semibold text-muted-foreground">Avg Weight (kg)</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {dailyRecords.slice(0, 10).map((record) => (
                    <tr key={record.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 px-3 font-medium">{format(new Date(record.recordDate), "MMM d, yyyy")}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className={record.mortality > 0 ? "text-red-600 font-medium" : "text-muted-foreground"}>
                          {record.mortality}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-muted-foreground">{Number(record.feedUsed).toFixed(1)}</td>
                      {flock.type === "layer" && (
                        <>
                          <td className="py-2.5 px-3 text-right">{record.eggsCollected ?? 0}</td>
                          <td className="py-2.5 px-3 text-right text-muted-foreground">{record.brokenEggs ?? 0}</td>
                        </>
                      )}
                      {flock.type === "broiler" && (
                        <td className="py-2.5 px-3 text-right">{record.averageWeight ? Number(record.averageWeight).toFixed(3) : "—"}</td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
