import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Bird, DollarSign, Skull, TrendingDown, TrendingUp, Wheat } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import { format, parseISO } from "date-fns";

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  colorClass,
  loading,
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ElementType;
  trend?: "up" | "down" | "neutral";
  colorClass: string;
  loading?: boolean;
}) {
  return (
    <Card className="border border-border/60 shadow-sm hover:shadow-md transition-all duration-200">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">
              {title}
            </p>
            {loading ? (
              <Skeleton className="h-8 w-24 mb-1" />
            ) : (
              <p className="text-3xl font-bold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                {value}
              </p>
            )}
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1.5">{subtitle}</p>
            )}
          </div>
          <div className={`h-12 w-12 rounded-xl flex items-center justify-center shrink-0 ml-4 ${colorClass}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        {trend && (
          <div className="mt-4 flex items-center gap-1.5">
            {trend === "up" ? (
              <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
            ) : trend === "down" ? (
              <TrendingDown className="h-3.5 w-3.5 text-red-500" />
            ) : null}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: summary, isLoading: summaryLoading } = trpc.dashboard.summary.useQuery();
  const { data: mortalityData, isLoading: mortalityLoading } = trpc.reports.mortalityLast30Days.useQuery();
  const { data: monthlyRevenue, isLoading: revenueLoading } = trpc.reports.monthlyRevenue.useQuery({ months: 6 });
  const { data: flocks } = trpc.flock.list.useQuery();

  const mortalityChartData = (mortalityData ?? []).map((d) => ({
    date: format(parseISO(d.date), "MMM d"),
    mortality: Number(d.total ?? 0),
  }));

  // Build monthly revenue chart data
  const revenueMap: Record<string, { month: string; eggs: number; birds: number }> = {};
  (monthlyRevenue?.eggs ?? []).forEach((e) => {
    const key = e.month;
    if (!revenueMap[key]) revenueMap[key] = { month: key, eggs: 0, birds: 0 };
    revenueMap[key].eggs = Number(e.total ?? 0);
  });
  (monthlyRevenue?.birds ?? []).forEach((b) => {
    const key = b.month;
    if (!revenueMap[key]) revenueMap[key] = { month: key, eggs: 0, birds: 0 };
    revenueMap[key].birds = Number(b.total ?? 0);
  });
  const revenueChartData = Object.values(revenueMap).sort((a, b) => a.month.localeCompare(b.month));

  const profitLoss = summary?.profitLoss ?? 0;
  const isProfitable = profitLoss >= 0;

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <Badge
          variant="outline"
          className={`text-xs px-3 py-1.5 font-medium ${isProfitable ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-red-50 text-red-700 border-red-200"}`}
        >
          {isProfitable ? <TrendingUp className="h-3 w-3 mr-1.5 inline" /> : <TrendingDown className="h-3 w-3 mr-1.5 inline" />}
          {isProfitable ? "Profitable" : "Loss"}
        </Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <StatCard
          title="Active Flocks"
          value={summaryLoading ? "—" : (summary?.activeFlocks ?? 0)}
          subtitle={`${flocks?.filter(f => f.status === "active").length ?? 0} flock(s) in operation`}
          icon={Bird}
          colorClass="bg-emerald-100 text-emerald-700"
          loading={summaryLoading}
        />
        <StatCard
          title="Today's Mortality"
          value={summaryLoading ? "—" : (summary?.todayMortality ?? 0)}
          subtitle="Birds lost today"
          icon={Skull}
          colorClass="bg-red-100 text-red-600"
          loading={summaryLoading}
        />
        <StatCard
          title="Feed Used Today"
          value={summaryLoading ? "—" : `${Number(summary?.todayFeedUsed ?? 0).toFixed(1)} kg`}
          subtitle="Total feed consumed"
          icon={Wheat}
          colorClass="bg-amber-100 text-amber-700"
          loading={summaryLoading}
        />
        <StatCard
          title="Total Revenue"
          value={summaryLoading ? "—" : `$${Number(summary?.totalRevenue ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          subtitle={`P&L: ${isProfitable ? "+" : ""}$${Number(profitLoss).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          icon={DollarSign}
          colorClass="bg-blue-100 text-blue-700"
          loading={summaryLoading}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Mortality Trend */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Mortality — Last 30 Days</CardTitle>
          </CardHeader>
          <CardContent>
            {mortalityLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : mortalityChartData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No mortality data yet. Start recording daily entries.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={mortalityChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="mortalityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="oklch(0.55 0.22 25)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ borderRadius: "8px", border: "1px solid oklch(0.87 0.018 140)", fontSize: "12px" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="mortality"
                    stroke="oklch(0.55 0.22 25)"
                    strokeWidth={2}
                    fill="url(#mortalityGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Revenue — Last 6 Months</CardTitle>
          </CardHeader>
          <CardContent>
            {revenueLoading ? (
              <Skeleton className="h-52 w-full" />
            ) : revenueChartData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                No revenue data yet. Record your first sale.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={revenueChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ borderRadius: "8px", border: "1px solid oklch(0.87 0.018 140)", fontSize: "12px" }}
                    formatter={(v: number) => [`$${v.toFixed(2)}`, ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: "12px" }} />
                  <Bar dataKey="eggs" name="Egg Sales" fill="oklch(0.40 0.13 155)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="birds" name="Bird Sales" fill="oklch(0.60 0.15 200)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Active Flocks Summary */}
      {flocks && flocks.filter(f => f.status === "active").length > 0 && (
        <Card className="border border-border/60 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Active Flocks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {flocks.filter(f => f.status === "active").map((flock) => (
                <div
                  key={flock.id}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border/60 bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => setLocation(`/flocks/${flock.id}`)}
                >
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Bird className="h-5 w-5 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">{flock.name}</p>
                    <p className="text-xs text-muted-foreground">{flock.breed}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0.5 ${flock.type === "layer" ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                        {flock.type === "layer" ? "Layer" : "Broiler"}
                      </Badge>
                      <span className="text-[10px] text-muted-foreground">{flock.initialCount.toLocaleString()} birds</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
