import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { ShoppingCart, Plus, Egg, Bird } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

function AddEggSaleDialog({ layerFlocks, onSuccess }: { layerFlocks: { id: number; name: string }[]; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    flockId: "",
    saleDate: new Date().toISOString().split("T")[0],
    quantity: "",
    pricePerEgg: "",
    buyer: "",
    notes: "",
  });

  const createSale = trpc.sales.createEggSale.useMutation({
    onSuccess: () => {
      toast.success("Egg sale recorded");
      setOpen(false);
      setForm({ flockId: "", saleDate: new Date().toISOString().split("T")[0], quantity: "", pricePerEgg: "", buyer: "", notes: "" });
      onSuccess();
    },
    onError: (err) => toast.error(err.message),
  });

  const totalRevenue = form.quantity && form.pricePerEgg
    ? (parseInt(form.quantity) * parseFloat(form.pricePerEgg)).toFixed(2)
    : "0.00";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.flockId || !form.quantity || !form.pricePerEgg) {
      toast.error("Please fill in all required fields");
      return;
    }
    createSale.mutate({
      flockId: parseInt(form.flockId),
      saleDate: form.saleDate,
      quantity: parseInt(form.quantity),
      pricePerEgg: parseFloat(form.pricePerEgg),
      buyer: form.buyer || undefined,
      notes: form.notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-amber-200 text-amber-700 hover:bg-amber-50">
          <Egg className="h-4 w-4" />Record Egg Sale
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Record Egg Sale</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Flock <span className="text-destructive">*</span></Label>
              <Select value={form.flockId} onValueChange={v => setForm(f => ({ ...f, flockId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select layer flock" /></SelectTrigger>
                <SelectContent>
                  {layerFlocks.map(fl => <SelectItem key={fl.id} value={String(fl.id)}>{fl.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Sale Date</Label>
              <Input type="date" value={form.saleDate} onChange={e => setForm(f => ({ ...f, saleDate: e.target.value }))} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Quantity (eggs) <span className="text-destructive">*</span></Label>
              <Input type="number" min="1" placeholder="e.g. 300" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Price per Egg ($) <span className="text-destructive">*</span></Label>
              <Input type="number" min="0" step="0.0001" placeholder="e.g. 0.15" value={form.pricePerEgg} onChange={e => setForm(f => ({ ...f, pricePerEgg: e.target.value }))} />
            </div>
          </div>
          {form.quantity && form.pricePerEgg && (
            <div className="rounded-lg bg-amber-50 border border-amber-200 px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-amber-700">Total Revenue</span>
              <span className="text-lg font-bold text-amber-700">${totalRevenue}</span>
            </div>
          )}
          <div className="space-y-1.5">
            <Label>Buyer</Label>
            <Input placeholder="e.g. Local Market" value={form.buyer} onChange={e => setForm(f => ({ ...f, buyer: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createSale.isPending}>{createSale.isPending ? "Saving..." : "Record Sale"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AddBirdSaleDialog({ broilerFlocks, onSuccess }: { broilerFlocks: { id: number; name: string }[]; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    flockId: "",
    saleDate: new Date().toISOString().split("T")[0],
    quantity: "",
    pricePerBird: "",
    averageWeight: "",
    buyer: "",
    notes: "",
  });

  const createSale = trpc.sales.createBirdSale.useMutation({
    onSuccess: () => {
      toast.success("Bird sale recorded");
      setOpen(false);
      setForm({ flockId: "", saleDate: new Date().toISOString().split("T")[0], quantity: "", pricePerBird: "", averageWeight: "", buyer: "", notes: "" });
      onSuccess();
    },
    onError: (err) => toast.error(err.message),
  });

  const totalRevenue = form.quantity && form.pricePerBird
    ? (parseInt(form.quantity) * parseFloat(form.pricePerBird)).toFixed(2)
    : "0.00";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.flockId || !form.quantity || !form.pricePerBird) {
      toast.error("Please fill in all required fields");
      return;
    }
    createSale.mutate({
      flockId: parseInt(form.flockId),
      saleDate: form.saleDate,
      quantity: parseInt(form.quantity),
      pricePerBird: parseFloat(form.pricePerBird),
      averageWeight: form.averageWeight ? parseFloat(form.averageWeight) : undefined,
      buyer: form.buyer || undefined,
      notes: form.notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-blue-200 text-blue-700 hover:bg-blue-50">
          <Bird className="h-4 w-4" />Record Bird Sale
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Record Bird Sale</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Flock <span className="text-destructive">*</span></Label>
              <Select value={form.flockId} onValueChange={v => setForm(f => ({ ...f, flockId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select broiler flock" /></SelectTrigger>
                <SelectContent>
                  {broilerFlocks.map(fl => <SelectItem key={fl.id} value={String(fl.id)}>{fl.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Sale Date</Label>
              <Input type="date" value={form.saleDate} onChange={e => setForm(f => ({ ...f, saleDate: e.target.value }))} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Quantity (birds) <span className="text-destructive">*</span></Label>
              <Input type="number" min="1" placeholder="e.g. 100" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Price per Bird ($) <span className="text-destructive">*</span></Label>
              <Input type="number" min="0" step="0.01" placeholder="e.g. 8.50" value={form.pricePerBird} onChange={e => setForm(f => ({ ...f, pricePerBird: e.target.value }))} />
            </div>
          </div>
          {form.quantity && form.pricePerBird && (
            <div className="rounded-lg bg-blue-50 border border-blue-200 px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-blue-700">Total Revenue</span>
              <span className="text-lg font-bold text-blue-700">${totalRevenue}</span>
            </div>
          )}
          <div className="space-y-1.5">
            <Label>Average Weight (kg)</Label>
            <Input type="number" min="0" step="0.001" placeholder="e.g. 2.100" value={form.averageWeight} onChange={e => setForm(f => ({ ...f, averageWeight: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Buyer</Label>
            <Input placeholder="e.g. Wholesale Market" value={form.buyer} onChange={e => setForm(f => ({ ...f, buyer: e.target.value }))} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createSale.isPending}>{createSale.isPending ? "Saving..." : "Record Sale"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Sales() {
  const utils = trpc.useUtils();
  const { data: flocks } = trpc.flock.list.useQuery();
  const { data: eggSales, isLoading: eggLoading } = trpc.sales.eggSales.useQuery();
  const { data: birdSales, isLoading: birdLoading } = trpc.sales.birdSales.useQuery();

  const activeFlocks = (flocks ?? []).filter(f => f.status === "active");
  const layerFlocks = activeFlocks.filter(f => f.type === "layer");
  const broilerFlocks = activeFlocks.filter(f => f.type === "broiler");

  const totalEggRevenue = (eggSales ?? []).reduce((s, e) => s + Number(e.totalRevenue), 0);
  const totalBirdRevenue = (birdSales ?? []).reduce((s, b) => s + Number(b.totalRevenue), 0);
  const totalRevenue = totalEggRevenue + totalBirdRevenue;

  const invalidateAll = () => {
    utils.sales.eggSales.invalidate();
    utils.sales.birdSales.invalidate();
    utils.dashboard.summary.invalidate();
  };

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Sales</h1>
          <p className="text-sm text-muted-foreground mt-1">Record egg sales and bird sales transactions</p>
        </div>
        <div className="flex gap-3 flex-wrap">
          <AddEggSaleDialog layerFlocks={layerFlocks} onSuccess={invalidateAll} />
          <AddBirdSaleDialog broilerFlocks={broilerFlocks} onSuccess={invalidateAll} />
        </div>
      </div>

      {/* Revenue Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Total Revenue", value: `$${totalRevenue.toFixed(2)}`, color: "text-primary" },
          { label: "Egg Sales Revenue", value: `$${totalEggRevenue.toFixed(2)}`, color: "text-amber-700" },
          { label: "Bird Sales Revenue", value: `$${totalBirdRevenue.toFixed(2)}`, color: "text-blue-700" },
        ].map(stat => (
          <Card key={stat.label} className="border border-border/60 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
              <p className={`text-2xl font-bold mt-1 ${stat.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="eggs">
        <TabsList className="mb-6">
          <TabsTrigger value="eggs" className="gap-2">
            <Egg className="h-4 w-4" />Egg Sales
            {eggSales && eggSales.length > 0 && (
              <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1.5">{eggSales.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="birds" className="gap-2">
            <Bird className="h-4 w-4" />Bird Sales
            {birdSales && birdSales.length > 0 && (
              <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1.5">{birdSales.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="eggs">
          <Card className="border border-border/60 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Egg className="h-4 w-4 text-amber-500" />Egg Sales History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {eggLoading ? (
                <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
              ) : !eggSales || eggSales.length === 0 ? (
                <div className="py-12 flex flex-col items-center gap-3">
                  <Egg className="h-10 w-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No egg sales recorded yet.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/60">
                        {["Date", "Flock", "Quantity", "Price/Egg", "Total Revenue", "Buyer"].map(h => (
                          <th key={h} className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {eggSales.map(sale => {
                        const flock = flocks?.find(f => f.id === sale.flockId);
                        return (
                          <tr key={sale.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                            <td className="py-2.5 px-3 font-medium whitespace-nowrap">{format(new Date(sale.saleDate), "MMM d, yyyy")}</td>
                            <td className="py-2.5 px-3">{flock?.name ?? "—"}</td>
                            <td className="py-2.5 px-3">{sale.quantity.toLocaleString()}</td>
                            <td className="py-2.5 px-3">${Number(sale.pricePerEgg).toFixed(4)}</td>
                            <td className="py-2.5 px-3 font-semibold text-amber-700">${Number(sale.totalRevenue).toFixed(2)}</td>
                            <td className="py-2.5 px-3 text-muted-foreground">{sale.buyer ?? "—"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="birds">
          <Card className="border border-border/60 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Bird className="h-4 w-4 text-blue-500" />Bird Sales History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {birdLoading ? (
                <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
              ) : !birdSales || birdSales.length === 0 ? (
                <div className="py-12 flex flex-col items-center gap-3">
                  <Bird className="h-10 w-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No bird sales recorded yet.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/60">
                        {["Date", "Flock", "Quantity", "Price/Bird", "Avg Weight", "Total Revenue", "Buyer"].map(h => (
                          <th key={h} className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {birdSales.map(sale => {
                        const flock = flocks?.find(f => f.id === sale.flockId);
                        return (
                          <tr key={sale.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                            <td className="py-2.5 px-3 font-medium whitespace-nowrap">{format(new Date(sale.saleDate), "MMM d, yyyy")}</td>
                            <td className="py-2.5 px-3">{flock?.name ?? "—"}</td>
                            <td className="py-2.5 px-3">{sale.quantity.toLocaleString()}</td>
                            <td className="py-2.5 px-3">${Number(sale.pricePerBird).toFixed(2)}</td>
                            <td className="py-2.5 px-3">{sale.averageWeight ? `${Number(sale.averageWeight).toFixed(3)} kg` : "—"}</td>
                            <td className="py-2.5 px-3 font-semibold text-blue-700">${Number(sale.totalRevenue).toFixed(2)}</td>
                            <td className="py-2.5 px-3 text-muted-foreground">{sale.buyer ?? "—"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
