import { trpc } from "@/lib/trpc";
import { Egg, Weight, Bird } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  LineChart, Line,
} from "recharts";
import { format } from "date-fns";

function LayerProductionPanel({ flocks }: { flocks: { id: number; name: string; type: string }[] }) {
  const layerFlocks = flocks.filter(f => f.type === "layer");

  return (
    <div className="space-y-6">
      {layerFlocks.length === 0 ? (
        <div className="py-16 flex flex-col items-center gap-3">
          <Egg className="h-10 w-10 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No active layer flocks. Add a layer flock to track egg production.</p>
        </div>
      ) : (
        layerFlocks.map(flock => <LayerFlockPanel key={flock.id} flockId={flock.id} flockName={flock.name} />)
      )}
    </div>
  );
}

function LayerFlockPanel({ flockId, flockName }: { flockId: number; flockName: string }) {
  const { data: records, isLoading } = trpc.dailyRecords.byFlock.useQuery({ flockId, limit: 30 });
  const { data: eggSales } = trpc.sales.eggSalesByFlock.useQuery({ flockId });

  const chartData = (records ?? [])
    .slice().reverse()
    .map(r => ({
      date: format(new Date(r.recordDate), "MMM d"),
      eggsCollected: r.eggsCollected ?? 0,
      brokenEggs: r.brokenEggs ?? 0,
      good: (r.eggsCollected ?? 0) - (r.brokenEggs ?? 0),
    }));

  const totalEggs = (records ?? []).reduce((s, r) => s + (r.eggsCollected ?? 0), 0);
  const totalBroken = (records ?? []).reduce((s, r) => s + (r.brokenEggs ?? 0), 0);
  const totalRevenue = (eggSales ?? []).reduce((s, e) => s + Number(e.totalRevenue), 0);

  return (
    <Card className="border border-border/60 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Egg className="h-4 w-4 text-amber-500" />
            {flockName}
          </CardTitle>
          <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">Layer</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: "Total Eggs Collected", value: totalEggs.toLocaleString(), color: "text-amber-700" },
            { label: "Broken Eggs", value: totalBroken.toLocaleString(), color: "text-red-600" },
            { label: "Egg Revenue", value: `$${totalRevenue.toFixed(2)}`, color: "text-primary" },
          ].map(s => (
            <div key={s.label} className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className={`text-xl font-bold mt-1 ${s.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{s.value}</p>
            </div>
          ))}
        </div>
        {isLoading ? (
          <Skeleton className="h-44 w-full" />
        ) : chartData.length === 0 ? (
          <div className="h-44 flex items-center justify-center text-muted-foreground text-sm">
            No production data yet. Add daily records for this flock.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: "8px", fontSize: "12px" }} />
              <Legend wrapperStyle={{ fontSize: "12px" }} />
              <Bar dataKey="good" name="Eggs Collected" fill="oklch(0.72 0.15 80)" radius={[3, 3, 0, 0]} stackId="a" />
              <Bar dataKey="brokenEggs" name="Broken Eggs" fill="oklch(0.55 0.22 25)" radius={[3, 3, 0, 0]} stackId="a" />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}

function BroilerProductionPanel({ flocks }: { flocks: { id: number; name: string; type: string }[] }) {
  const broilerFlocks = flocks.filter(f => f.type === "broiler");

  return (
    <div className="space-y-6">
      {broilerFlocks.length === 0 ? (
        <div className="py-16 flex flex-col items-center gap-3">
          <Weight className="h-10 w-10 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No active broiler flocks. Add a broiler flock to track weight progress.</p>
        </div>
      ) : (
        broilerFlocks.map(flock => <BroilerFlockPanel key={flock.id} flockId={flock.id} flockName={flock.name} />)
      )}
    </div>
  );
}

function BroilerFlockPanel({ flockId, flockName }: { flockId: number; flockName: string }) {
  const { data: records, isLoading } = trpc.dailyRecords.byFlock.useQuery({ flockId, limit: 30 });
  const { data: birdSales } = trpc.sales.birdSalesByFlock.useQuery({ flockId });

  const chartData = (records ?? [])
    .filter(r => r.averageWeight)
    .slice().reverse()
    .map(r => ({
      date: format(new Date(r.recordDate), "MMM d"),
      averageWeight: Number(r.averageWeight),
    }));

  const latestWeight = chartData.length > 0 ? chartData[chartData.length - 1]?.averageWeight : null;
  const totalRevenue = (birdSales ?? []).reduce((s, b) => s + Number(b.totalRevenue), 0);
  const totalBirdsSold = (birdSales ?? []).reduce((s, b) => s + b.quantity, 0);

  return (
    <Card className="border border-border/60 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Bird className="h-4 w-4 text-blue-500" />
            {flockName}
          </CardTitle>
          <Badge variant="outline" className="text-[10px] bg-blue-50 text-blue-700 border-blue-200">Broiler</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: "Current Avg Weight", value: latestWeight ? `${latestWeight.toFixed(3)} kg` : "—", color: "text-blue-700" },
            { label: "Birds Sold", value: totalBirdsSold.toLocaleString(), color: "text-foreground" },
            { label: "Sales Revenue", value: `$${totalRevenue.toFixed(2)}`, color: "text-primary" },
          ].map(s => (
            <div key={s.label} className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className={`text-xl font-bold mt-1 ${s.color}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{s.value}</p>
            </div>
          ))}
        </div>
        {isLoading ? (
          <Skeleton className="h-44 w-full" />
        ) : chartData.length === 0 ? (
          <div className="h-44 flex items-center justify-center text-muted-foreground text-sm">
            No weight data yet. Record average weight in daily entries.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.87 0.018 140)" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit=" kg" />
              <Tooltip contentStyle={{ borderRadius: "8px", fontSize: "12px" }} formatter={(v: number) => [`${v.toFixed(3)} kg`, "Avg Weight"]} />
              <Line type="monotone" dataKey="averageWeight" stroke="oklch(0.60 0.15 200)" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}

export default function Production() {
  const { data: flocks, isLoading } = trpc.flock.list.useQuery();
  const activeFlocks = (flocks ?? []).filter(f => f.status === "active");
  const layerCount = activeFlocks.filter(f => f.type === "layer").length;
  const broilerCount = activeFlocks.filter(f => f.type === "broiler").length;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Production Tracking</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Monitor egg production for layers and weight progress for broilers
        </p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-64 w-full rounded-xl" />
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      ) : (
        <Tabs defaultValue="layers">
          <TabsList className="mb-6">
            <TabsTrigger value="layers" className="gap-2">
              <Egg className="h-4 w-4" />
              Layers
              {layerCount > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1.5">{layerCount}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="broilers" className="gap-2">
              <Bird className="h-4 w-4" />
              Broilers
              {broilerCount > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1.5">{broilerCount}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="layers">
            <LayerProductionPanel flocks={activeFlocks} />
          </TabsContent>
          <TabsContent value="broilers">
            <BroilerProductionPanel flocks={activeFlocks} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
