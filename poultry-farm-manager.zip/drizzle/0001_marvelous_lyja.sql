CREATE TABLE `bird_sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`flockId` int NOT NULL,
	`saleDate` date NOT NULL,
	`quantity` int NOT NULL,
	`pricePerBird` decimal(10,2) NOT NULL,
	`totalRevenue` decimal(10,2) NOT NULL,
	`averageWeight` decimal(8,3),
	`buyer` varchar(256),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bird_sales_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `daily_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`flockId` int NOT NULL,
	`userId` int NOT NULL,
	`recordDate` date NOT NULL,
	`mortality` int NOT NULL DEFAULT 0,
	`feedUsed` decimal(10,2) NOT NULL DEFAULT '0',
	`eggsCollected` int DEFAULT 0,
	`brokenEggs` int DEFAULT 0,
	`averageWeight` decimal(8,3),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `egg_sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`flockId` int NOT NULL,
	`saleDate` date NOT NULL,
	`quantity` int NOT NULL,
	`pricePerEgg` decimal(8,4) NOT NULL,
	`totalRevenue` decimal(10,2) NOT NULL,
	`buyer` varchar(256),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `egg_sales_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`flockId` int,
	`expenseDate` date NOT NULL,
	`category` enum('feed','medication','labor','utilities','miscellaneous') NOT NULL,
	`description` varchar(512) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `feed_purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`flockId` int,
	`purchaseDate` date NOT NULL,
	`feedType` varchar(128) NOT NULL,
	`quantityKg` decimal(10,2) NOT NULL,
	`costPerKg` decimal(10,2) NOT NULL,
	`totalCost` decimal(10,2) NOT NULL,
	`supplier` varchar(256),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `feed_purchases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `flocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(128) NOT NULL,
	`breed` varchar(128) NOT NULL,
	`type` enum('layer','broiler') NOT NULL,
	`arrivalDate` date NOT NULL,
	`initialCount` int NOT NULL,
	`supplier` varchar(256),
	`notes` text,
	`status` enum('active','closed') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `flocks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('farm_owner','manager') NOT NULL DEFAULT 'manager';