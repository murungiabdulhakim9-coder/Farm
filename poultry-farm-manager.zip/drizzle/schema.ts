import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  date,
} from "drizzle-orm/mysql-core";

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["farm_owner", "manager"]).default("manager").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Flocks ──────────────────────────────────────────────────────────────────
export const flocks = mysqlTable("flocks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  breed: varchar("breed", { length: 128 }).notNull(),
  type: mysqlEnum("type", ["layer", "broiler"]).notNull(),
  arrivalDate: date("arrivalDate").notNull(),
  initialCount: int("initialCount").notNull(),
  supplier: varchar("supplier", { length: 256 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["active", "closed"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Flock = typeof flocks.$inferSelect;
export type InsertFlock = typeof flocks.$inferInsert;

// ─── Daily Records ────────────────────────────────────────────────────────────
export const dailyRecords = mysqlTable("daily_records", {
  id: int("id").autoincrement().primaryKey(),
  flockId: int("flockId").notNull(),
  userId: int("userId").notNull(),
  recordDate: date("recordDate").notNull(),
  mortality: int("mortality").default(0).notNull(),
  feedUsed: decimal("feedUsed", { precision: 10, scale: 2 }).default("0").notNull(), // kg
  // Layer fields
  eggsCollected: int("eggsCollected").default(0),
  brokenEggs: int("brokenEggs").default(0),
  // Broiler fields
  averageWeight: decimal("averageWeight", { precision: 8, scale: 3 }), // kg
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyRecord = typeof dailyRecords.$inferSelect;
export type InsertDailyRecord = typeof dailyRecords.$inferInsert;

// ─── Feed Purchases ───────────────────────────────────────────────────────────
export const feedPurchases = mysqlTable("feed_purchases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  flockId: int("flockId"),
  purchaseDate: date("purchaseDate").notNull(),
  feedType: varchar("feedType", { length: 128 }).notNull(),
  quantityKg: decimal("quantityKg", { precision: 10, scale: 2 }).notNull(),
  costPerKg: decimal("costPerKg", { precision: 10, scale: 2 }).notNull(),
  totalCost: decimal("totalCost", { precision: 10, scale: 2 }).notNull(),
  supplier: varchar("supplier", { length: 256 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FeedPurchase = typeof feedPurchases.$inferSelect;
export type InsertFeedPurchase = typeof feedPurchases.$inferInsert;

// ─── Expenses ─────────────────────────────────────────────────────────────────
export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  flockId: int("flockId"),
  expenseDate: date("expenseDate").notNull(),
  category: mysqlEnum("category", ["feed", "medication", "labor", "utilities", "miscellaneous"]).notNull(),
  description: varchar("description", { length: 512 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;

// ─── Egg Sales ────────────────────────────────────────────────────────────────
export const eggSales = mysqlTable("egg_sales", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  flockId: int("flockId").notNull(),
  saleDate: date("saleDate").notNull(),
  quantity: int("quantity").notNull(), // number of eggs
  pricePerEgg: decimal("pricePerEgg", { precision: 8, scale: 4 }).notNull(),
  totalRevenue: decimal("totalRevenue", { precision: 10, scale: 2 }).notNull(),
  buyer: varchar("buyer", { length: 256 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EggSale = typeof eggSales.$inferSelect;
export type InsertEggSale = typeof eggSales.$inferInsert;

// ─── Bird Sales ───────────────────────────────────────────────────────────────
export const birdSales = mysqlTable("bird_sales", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  flockId: int("flockId").notNull(),
  saleDate: date("saleDate").notNull(),
  quantity: int("quantity").notNull(),
  pricePerBird: decimal("pricePerBird", { precision: 10, scale: 2 }).notNull(),
  totalRevenue: decimal("totalRevenue", { precision: 10, scale: 2 }).notNull(),
  averageWeight: decimal("averageWeight", { precision: 8, scale: 3 }), // kg
  buyer: varchar("buyer", { length: 256 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BirdSale = typeof birdSales.$inferSelect;
export type InsertBirdSale = typeof birdSales.$inferInsert;
