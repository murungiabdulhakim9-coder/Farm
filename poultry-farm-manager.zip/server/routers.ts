import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createFlock,
  getFlocksByUser,
  getFlockById,
  updateFlockStatus,
  getActiveFlockCount,
  upsertDailyRecord,
  getDailyRecordsByFlock,
  getDailyRecordsByUser,
  getTodayMortality,
  getTodayFeedUsed,
  getFlockMortalityStats,
  getFlockFeedUsed,
  createFeedPurchase,
  getFeedPurchasesByUser,
  getTotalFeedCost,
  createExpense,
  getExpensesByUser,
  getExpensesByCategory,
  getTotalExpenses,
  createEggSale,
  getEggSalesByFlock,
  getEggSalesByUser,
  getTotalEggRevenue,
  createBirdSale,
  getBirdSalesByFlock,
  getBirdSalesByUser,
  getTotalBirdRevenue,
  getMonthlyExpenses,
  getMonthlyRevenue,
  getDailyMortalityLast30,
} from "./db";

// ─── Flock Router ─────────────────────────────────────────────────────────────
const flockRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        breed: z.string().min(1),
        type: z.enum(["layer", "broiler"]),
        arrivalDate: z.string(),
        initialCount: z.number().int().positive(),
        supplier: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createFlock({
        userId: ctx.user.id,
        name: input.name,
        breed: input.breed,
        type: input.type,
        arrivalDate: input.arrivalDate as unknown as Date,
        initialCount: input.initialCount,
        supplier: input.supplier,
        notes: input.notes,
        status: "active",
      });
      return { success: true };
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return getFlocksByUser(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const flock = await getFlockById(input.id);
      if (!flock || flock.userId !== ctx.user.id) throw new Error("Flock not found");
      const mortalityStats = await getFlockMortalityStats(flock.id);
      const totalFeedUsed = await getFlockFeedUsed(flock.id);
      const currentCount = flock.initialCount - mortalityStats.totalMortality;
      const mortalityRate = flock.initialCount > 0
        ? ((mortalityStats.totalMortality / flock.initialCount) * 100).toFixed(2)
        : "0.00";
      return { ...flock, ...mortalityStats, totalFeedUsed, currentCount, mortalityRate };
    }),

  updateStatus: protectedProcedure
    .input(z.object({ id: z.number(), status: z.enum(["active", "closed"]) }))
    .mutation(async ({ ctx, input }) => {
      const flock = await getFlockById(input.id);
      if (!flock || flock.userId !== ctx.user.id) throw new Error("Flock not found");
      await updateFlockStatus(input.id, input.status);
      return { success: true };
    }),
});

// ─── Daily Records Router ─────────────────────────────────────────────────────
const dailyRecordsRouter = router({
  upsert: protectedProcedure
    .input(
      z.object({
        flockId: z.number(),
        recordDate: z.string(),
        mortality: z.number().int().min(0).default(0),
        feedUsed: z.number().min(0).default(0),
        eggsCollected: z.number().int().min(0).optional(),
        brokenEggs: z.number().int().min(0).optional(),
        averageWeight: z.number().min(0).optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await upsertDailyRecord({
        flockId: input.flockId,
        userId: ctx.user.id,
        recordDate: input.recordDate as unknown as Date,
        mortality: input.mortality,
        feedUsed: String(input.feedUsed),
        eggsCollected: input.eggsCollected,
        brokenEggs: input.brokenEggs,
        averageWeight: input.averageWeight !== undefined ? String(input.averageWeight) : undefined,
        notes: input.notes,
      });
      return { success: true };
    }),

  byFlock: protectedProcedure
    .input(z.object({ flockId: z.number(), limit: z.number().optional() }))
    .query(async ({ input }) => {
      return getDailyRecordsByFlock(input.flockId, input.limit);
    }),

  recent: protectedProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getDailyRecordsByUser(ctx.user.id, input.limit);
    }),
});

// ─── Feed Router ──────────────────────────────────────────────────────────────
const feedRouter = router({
  createPurchase: protectedProcedure
    .input(
      z.object({
        flockId: z.number().optional(),
        purchaseDate: z.string(),
        feedType: z.string().min(1),
        quantityKg: z.number().positive(),
        costPerKg: z.number().positive(),
        supplier: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const totalCost = input.quantityKg * input.costPerKg;
      await createFeedPurchase({
        userId: ctx.user.id,
        flockId: input.flockId,
        purchaseDate: input.purchaseDate as unknown as Date,
        feedType: input.feedType,
        quantityKg: String(input.quantityKg),
        costPerKg: String(input.costPerKg),
        totalCost: String(totalCost),
        supplier: input.supplier,
        notes: input.notes,
      });
      return { success: true };
    }),

  purchases: protectedProcedure.query(async ({ ctx }) => {
    return getFeedPurchasesByUser(ctx.user.id);
  }),

  fcrAndCostPerBird: protectedProcedure
    .input(z.object({ flockId: z.number() }))
    .query(async ({ input }) => {
      const flock = await getFlockById(input.flockId);
      if (!flock) throw new Error("Flock not found");
      const totalFeedUsed = await getFlockFeedUsed(input.flockId);
      const mortalityStats = await getFlockMortalityStats(input.flockId);
      const currentCount = flock.initialCount - mortalityStats.totalMortality;
      const fcr = currentCount > 0 && totalFeedUsed > 0
        ? (totalFeedUsed / currentCount).toFixed(3)
        : "0.000";
      const totalFeedCostForFlock = await (async () => {
        const purchases = await getFeedPurchasesByUser(flock.userId);
        const flockPurchases = purchases.filter(p => p.flockId === input.flockId);
        return flockPurchases.reduce((sum, p) => sum + Number(p.totalCost), 0);
      })();
      const costPerBird = currentCount > 0 && totalFeedCostForFlock > 0
        ? (totalFeedCostForFlock / currentCount).toFixed(2)
        : "0.00";
      return { fcr, costPerBird, totalFeedUsed, totalFeedCostForFlock, currentCount };
    }),
});

// ─── Expense Router ───────────────────────────────────────────────────────────
const expenseRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        flockId: z.number().optional(),
        expenseDate: z.string(),
        category: z.enum(["feed", "medication", "labor", "utilities", "miscellaneous"]),
        description: z.string().min(1),
        amount: z.number().positive(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createExpense({
        userId: ctx.user.id,
        flockId: input.flockId,
        expenseDate: input.expenseDate as unknown as Date,
        category: input.category,
        description: input.description,
        amount: String(input.amount),
        notes: input.notes,
      });
      return { success: true };
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return getExpensesByUser(ctx.user.id);
  }),

  byCategory: protectedProcedure.query(async ({ ctx }) => {
    return getExpensesByCategory(ctx.user.id);
  }),
});

// ─── Sales Router ─────────────────────────────────────────────────────────────
const salesRouter = router({
  createEggSale: protectedProcedure
    .input(
      z.object({
        flockId: z.number(),
        saleDate: z.string(),
        quantity: z.number().int().positive(),
        pricePerEgg: z.number().positive(),
        buyer: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const totalRevenue = input.quantity * input.pricePerEgg;
      await createEggSale({
        userId: ctx.user.id,
        flockId: input.flockId,
        saleDate: input.saleDate as unknown as Date,
        quantity: input.quantity,
        pricePerEgg: String(input.pricePerEgg),
        totalRevenue: String(totalRevenue),
        buyer: input.buyer,
        notes: input.notes,
      });
      return { success: true };
    }),

  eggSalesByFlock: protectedProcedure
    .input(z.object({ flockId: z.number() }))
    .query(async ({ input }) => getEggSalesByFlock(input.flockId)),

  eggSales: protectedProcedure.query(async ({ ctx }) => getEggSalesByUser(ctx.user.id)),

  createBirdSale: protectedProcedure
    .input(
      z.object({
        flockId: z.number(),
        saleDate: z.string(),
        quantity: z.number().int().positive(),
        pricePerBird: z.number().positive(),
        averageWeight: z.number().optional(),
        buyer: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const totalRevenue = input.quantity * input.pricePerBird;
      await createBirdSale({
        userId: ctx.user.id,
        flockId: input.flockId,
        saleDate: input.saleDate as unknown as Date,
        quantity: input.quantity,
        pricePerBird: String(input.pricePerBird),
        totalRevenue: String(totalRevenue),
        averageWeight: input.averageWeight !== undefined ? String(input.averageWeight) : undefined,
        buyer: input.buyer,
        notes: input.notes,
      });
      return { success: true };
    }),

  birdSalesByFlock: protectedProcedure
    .input(z.object({ flockId: z.number() }))
    .query(async ({ input }) => getBirdSalesByFlock(input.flockId)),

  birdSales: protectedProcedure.query(async ({ ctx }) => getBirdSalesByUser(ctx.user.id)),
});

// ─── Dashboard Router ─────────────────────────────────────────────────────────
const dashboardRouter = router({
  summary: protectedProcedure.query(async ({ ctx }) => {
    const [activeFlocks, todayMortality, todayFeedUsed, totalEggRevenue, totalBirdRevenue, totalExpenses] =
      await Promise.all([
        getActiveFlockCount(ctx.user.id),
        getTodayMortality(ctx.user.id),
        getTodayFeedUsed(ctx.user.id),
        getTotalEggRevenue(ctx.user.id),
        getTotalBirdRevenue(ctx.user.id),
        getTotalExpenses(ctx.user.id),
      ]);
    const totalRevenue = totalEggRevenue + totalBirdRevenue;
    const profitLoss = totalRevenue - totalExpenses;
    return { activeFlocks, todayMortality, todayFeedUsed, totalRevenue, totalExpenses, profitLoss };
  }),
});

// ─── Reports Router ───────────────────────────────────────────────────────────
const reportsRouter = router({
  mortalityLast30Days: protectedProcedure.query(async ({ ctx }) => {
    return getDailyMortalityLast30(ctx.user.id);
  }),

  expensesByCategory: protectedProcedure.query(async ({ ctx }) => {
    return getExpensesByCategory(ctx.user.id);
  }),

  monthlyExpenses: protectedProcedure
    .input(z.object({ months: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getMonthlyExpenses(ctx.user.id, input.months);
    }),

  monthlyRevenue: protectedProcedure
    .input(z.object({ months: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getMonthlyRevenue(ctx.user.id, input.months);
    }),

  feedUsagePerFlock: protectedProcedure.query(async ({ ctx }) => {
    const userFlocks = await getFlocksByUser(ctx.user.id);
    const results = await Promise.all(
      userFlocks.map(async (flock) => {
        const totalFeedUsed = await getFlockFeedUsed(flock.id);
        const mortalityStats = await getFlockMortalityStats(flock.id);
        const currentCount = flock.initialCount - mortalityStats.totalMortality;
        const fcr = currentCount > 0 && totalFeedUsed > 0
          ? Number((totalFeedUsed / currentCount).toFixed(3))
          : 0;
        return { flockId: flock.id, flockName: flock.name, breed: flock.breed, type: flock.type, totalFeedUsed, fcr, currentCount };
      })
    );
    return results;
  }),

  profitLoss: protectedProcedure.query(async ({ ctx }) => {
    const [totalEggRevenue, totalBirdRevenue, totalExpenses, expensesByCategory] = await Promise.all([
      getTotalEggRevenue(ctx.user.id),
      getTotalBirdRevenue(ctx.user.id),
      getTotalExpenses(ctx.user.id),
      getExpensesByCategory(ctx.user.id),
    ]);
    const totalRevenue = totalEggRevenue + totalBirdRevenue;
    const profitLoss = totalRevenue - totalExpenses;
    return { totalRevenue, totalEggRevenue, totalBirdRevenue, totalExpenses, profitLoss, expensesByCategory };
  }),

  flockMortalityRates: protectedProcedure.query(async ({ ctx }) => {
    const userFlocks = await getFlocksByUser(ctx.user.id);
    const results = await Promise.all(
      userFlocks.map(async (flock) => {
        const mortalityStats = await getFlockMortalityStats(flock.id);
        const mortalityRate = flock.initialCount > 0
          ? Number(((mortalityStats.totalMortality / flock.initialCount) * 100).toFixed(2))
          : 0;
        return { flockId: flock.id, flockName: flock.name, breed: flock.breed, initialCount: flock.initialCount, totalMortality: mortalityStats.totalMortality, mortalityRate };
      })
    );
    return results;
  }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  flock: flockRouter,
  dailyRecords: dailyRecordsRouter,
  feed: feedRouter,
  expense: expenseRouter,
  sales: salesRouter,
  dashboard: dashboardRouter,
  reports: reportsRouter,
});

export type AppRouter = typeof appRouter;
