import { and, desc, eq, gte, lte, sql, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  birdSales,
  dailyRecords,
  eggSales,
  expenses,
  feedPurchases,
  flocks,
  users,
  type InsertBirdSale,
  type InsertDailyRecord,
  type InsertEggSale,
  type InsertExpense,
  type InsertFeedPurchase,
  type InsertFlock,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "farm_owner"; updateSet.role = "farm_owner"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Flocks ───────────────────────────────────────────────────────────────────
export async function createFlock(data: InsertFlock) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(flocks).values(data);
  return result[0];
}

export async function getFlocksByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(flocks).where(eq(flocks.userId, userId)).orderBy(desc(flocks.createdAt));
}

export async function getFlockById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(flocks).where(eq(flocks.id, id)).limit(1);
  return result[0];
}

export async function updateFlockStatus(id: number, status: "active" | "closed") {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(flocks).set({ status }).where(eq(flocks.id, id));
}

export async function getActiveFlockCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(flocks)
    .where(and(eq(flocks.userId, userId), eq(flocks.status, "active")));
  return Number(result[0]?.count ?? 0);
}

// ─── Daily Records ────────────────────────────────────────────────────────────
export async function upsertDailyRecord(data: InsertDailyRecord) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .insert(dailyRecords)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        mortality: data.mortality,
        feedUsed: data.feedUsed,
        eggsCollected: data.eggsCollected,
        brokenEggs: data.brokenEggs,
        averageWeight: data.averageWeight,
        notes: data.notes,
      },
    });
}

export async function getDailyRecordsByFlock(flockId: number, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dailyRecords)
    .where(eq(dailyRecords.flockId, flockId))
    .orderBy(desc(dailyRecords.recordDate))
    .limit(limit);
}

export async function getDailyRecordsByUser(userId: number, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dailyRecords)
    .where(eq(dailyRecords.userId, userId))
    .orderBy(desc(dailyRecords.recordDate))
    .limit(limit);
}

export async function getTodayMortality(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const today = new Date().toISOString().split("T")[0];
  const result = await db
    .select({ total: sum(dailyRecords.mortality) })
    .from(dailyRecords)
    .where(and(eq(dailyRecords.userId, userId), eq(dailyRecords.recordDate, today as unknown as Date)));
  return Number(result[0]?.total ?? 0);
}

export async function getTodayFeedUsed(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const today = new Date().toISOString().split("T")[0];
  const result = await db
    .select({ total: sum(dailyRecords.feedUsed) })
    .from(dailyRecords)
    .where(and(eq(dailyRecords.userId, userId), eq(dailyRecords.recordDate, today as unknown as Date)));
  return Number(result[0]?.total ?? 0);
}

export async function getFlockMortalityStats(flockId: number) {
  const db = await getDb();
  if (!db) return { totalMortality: 0 };
  const result = await db
    .select({ totalMortality: sum(dailyRecords.mortality) })
    .from(dailyRecords)
    .where(eq(dailyRecords.flockId, flockId));
  return { totalMortality: Number(result[0]?.totalMortality ?? 0) };
}

export async function getFlockFeedUsed(flockId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ total: sum(dailyRecords.feedUsed) })
    .from(dailyRecords)
    .where(eq(dailyRecords.flockId, flockId));
  return Number(result[0]?.total ?? 0);
}

// ─── Feed Purchases ───────────────────────────────────────────────────────────
export async function createFeedPurchase(data: InsertFeedPurchase) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(feedPurchases).values(data);
}

export async function getFeedPurchasesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(feedPurchases).where(eq(feedPurchases.userId, userId)).orderBy(desc(feedPurchases.purchaseDate));
}

export async function getTotalFeedCost(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ total: sum(feedPurchases.totalCost) })
    .from(feedPurchases)
    .where(eq(feedPurchases.userId, userId));
  return Number(result[0]?.total ?? 0);
}

// ─── Expenses ─────────────────────────────────────────────────────────────────
export async function createExpense(data: InsertExpense) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(expenses).values(data);
}

export async function getExpensesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(expenses).where(eq(expenses.userId, userId)).orderBy(desc(expenses.expenseDate));
}

export async function getExpensesByCategory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ category: expenses.category, total: sum(expenses.amount) })
    .from(expenses)
    .where(eq(expenses.userId, userId))
    .groupBy(expenses.category);
}

export async function getTotalExpenses(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ total: sum(expenses.amount) })
    .from(expenses)
    .where(eq(expenses.userId, userId));
  return Number(result[0]?.total ?? 0);
}

// ─── Egg Sales ────────────────────────────────────────────────────────────────
export async function createEggSale(data: InsertEggSale) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(eggSales).values(data);
}

export async function getEggSalesByFlock(flockId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eggSales).where(eq(eggSales.flockId, flockId)).orderBy(desc(eggSales.saleDate));
}

export async function getEggSalesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eggSales).where(eq(eggSales.userId, userId)).orderBy(desc(eggSales.saleDate));
}

export async function getTotalEggRevenue(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ total: sum(eggSales.totalRevenue) })
    .from(eggSales)
    .where(eq(eggSales.userId, userId));
  return Number(result[0]?.total ?? 0);
}

// ─── Bird Sales ───────────────────────────────────────────────────────────────
export async function createBirdSale(data: InsertBirdSale) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(birdSales).values(data);
}

export async function getBirdSalesByFlock(flockId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(birdSales).where(eq(birdSales.flockId, flockId)).orderBy(desc(birdSales.saleDate));
}

export async function getBirdSalesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(birdSales).where(eq(birdSales.userId, userId)).orderBy(desc(birdSales.saleDate));
}

export async function getTotalBirdRevenue(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ total: sum(birdSales.totalRevenue) })
    .from(birdSales)
    .where(eq(birdSales.userId, userId));
  return Number(result[0]?.total ?? 0);
}

// ─── Reports ──────────────────────────────────────────────────────────────────
export async function getMonthlyExpenses(userId: number, months = 6) {
  const db = await getDb();
  if (!db) return [];
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);
  return db
    .select({
      month: sql<string>`DATE_FORMAT(expenseDate, '%Y-%m')`,
      total: sum(expenses.amount),
      category: expenses.category,
    })
    .from(expenses)
    .where(and(eq(expenses.userId, userId), gte(expenses.expenseDate, startDate as unknown as Date)))
    .groupBy(sql`DATE_FORMAT(expenseDate, '%Y-%m')`, expenses.category)
    .orderBy(sql`DATE_FORMAT(expenseDate, '%Y-%m')`);
}

export async function getMonthlyRevenue(userId: number, months = 6) {
  const db = await getDb();
  if (!db) return { eggs: [], birds: [] };
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);

  const eggs = await db
    .select({
      month: sql<string>`DATE_FORMAT(saleDate, '%Y-%m')`,
      total: sum(eggSales.totalRevenue),
    })
    .from(eggSales)
    .where(and(eq(eggSales.userId, userId), gte(eggSales.saleDate, startDate as unknown as Date)))
    .groupBy(sql`DATE_FORMAT(saleDate, '%Y-%m')`)
    .orderBy(sql`DATE_FORMAT(saleDate, '%Y-%m')`);

  const birds = await db
    .select({
      month: sql<string>`DATE_FORMAT(saleDate, '%Y-%m')`,
      total: sum(birdSales.totalRevenue),
    })
    .from(birdSales)
    .where(and(eq(birdSales.userId, userId), gte(birdSales.saleDate, startDate as unknown as Date)))
    .groupBy(sql`DATE_FORMAT(saleDate, '%Y-%m')`)
    .orderBy(sql`DATE_FORMAT(saleDate, '%Y-%m')`);

  return { eggs, birds };
}

export async function getDailyMortalityLast30(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 30);
  return db
    .select({
      date: sql<string>`DATE_FORMAT(recordDate, '%Y-%m-%d')`,
      total: sum(dailyRecords.mortality),
    })
    .from(dailyRecords)
    .where(and(eq(dailyRecords.userId, userId), gte(dailyRecords.recordDate, startDate as unknown as Date)))
    .groupBy(sql`DATE_FORMAT(recordDate, '%Y-%m-%d')`)
    .orderBy(sql`DATE_FORMAT(recordDate, '%Y-%m-%d')`);
}
