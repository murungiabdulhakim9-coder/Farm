import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock all DB helpers ───────────────────────────────────────────────────────
vi.mock("./db", () => ({
  createFlock: vi.fn().mockResolvedValue(undefined),
  getFlocksByUser: vi.fn().mockResolvedValue([
    {
      id: 1,
      userId: 1,
      name: "Batch A",
      breed: "ISA Brown",
      type: "layer",
      arrivalDate: new Date("2025-01-01"),
      initialCount: 500,
      supplier: "Green Valley",
      notes: null,
      status: "active",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  getFlockById: vi.fn().mockResolvedValue({
    id: 1,
    userId: 1,
    name: "Batch A",
    breed: "ISA Brown",
    type: "layer",
    arrivalDate: new Date("2025-01-01"),
    initialCount: 500,
    supplier: "Green Valley",
    notes: null,
    status: "active",
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  updateFlockStatus: vi.fn().mockResolvedValue(undefined),
  getActiveFlockCount: vi.fn().mockResolvedValue(2),
  upsertDailyRecord: vi.fn().mockResolvedValue(undefined),
  getDailyRecordsByFlock: vi.fn().mockResolvedValue([]),
  getDailyRecordsByUser: vi.fn().mockResolvedValue([]),
  getTodayMortality: vi.fn().mockResolvedValue(3),
  getTodayFeedUsed: vi.fn().mockResolvedValue(45.5),
  getFlockMortalityStats: vi.fn().mockResolvedValue({ totalMortality: 10 }),
  getFlockFeedUsed: vi.fn().mockResolvedValue(200),
  createFeedPurchase: vi.fn().mockResolvedValue(undefined),
  getFeedPurchasesByUser: vi.fn().mockResolvedValue([]),
  getTotalFeedCost: vi.fn().mockResolvedValue(500),
  createExpense: vi.fn().mockResolvedValue(undefined),
  getExpensesByUser: vi.fn().mockResolvedValue([]),
  getExpensesByCategory: vi.fn().mockResolvedValue([]),
  getTotalExpenses: vi.fn().mockResolvedValue(1200),
  createEggSale: vi.fn().mockResolvedValue(undefined),
  getEggSalesByFlock: vi.fn().mockResolvedValue([]),
  getEggSalesByUser: vi.fn().mockResolvedValue([]),
  getTotalEggRevenue: vi.fn().mockResolvedValue(800),
  createBirdSale: vi.fn().mockResolvedValue(undefined),
  getBirdSalesByFlock: vi.fn().mockResolvedValue([]),
  getBirdSalesByUser: vi.fn().mockResolvedValue([]),
  getTotalBirdRevenue: vi.fn().mockResolvedValue(400),
  getMonthlyExpenses: vi.fn().mockResolvedValue([]),
  getMonthlyRevenue: vi.fn().mockResolvedValue({ eggs: [], birds: [] }),
  getDailyMortalityLast30: vi.fn().mockResolvedValue([]),
}));

// ─── Helper: build a mock context ─────────────────────────────────────────────
function makeCtx(role: "farm_owner" | "manager" = "farm_owner"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-open-id",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

// ─── Auth Tests ────────────────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const ctx = makeCtx();
    const clearedCookies: string[] = [];
    ctx.res.clearCookie = (name: string) => { clearedCookies.push(name); };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(clearedCookies).toHaveLength(1);
  });

  it("returns current user from auth.me", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user?.name).toBe("Test User");
    expect(user?.role).toBe("farm_owner");
  });
});

// ─── Flock Tests ───────────────────────────────────────────────────────────────
describe("flock router", () => {
  it("creates a flock successfully", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.flock.create({
      name: "Batch B",
      breed: "Ross 308",
      type: "broiler",
      arrivalDate: "2025-03-01",
      initialCount: 1000,
      supplier: "AgriCo",
    });
    expect(result.success).toBe(true);
  });

  it("lists flocks for authenticated user", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const flocks = await caller.flock.list();
    expect(Array.isArray(flocks)).toBe(true);
    expect(flocks.length).toBeGreaterThan(0);
    expect(flocks[0]?.name).toBe("Batch A");
  });

  it("gets a single flock with computed stats", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const flock = await caller.flock.get({ id: 1 });
    expect(flock.id).toBe(1);
    expect(flock.currentCount).toBe(490); // 500 - 10 mortality
    expect(flock.totalMortality).toBe(10);
    expect(flock.mortalityRate).toBe("2.00");
    expect(Number(flock.totalFeedUsed)).toBe(200);
  });

  it("updates flock status", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.flock.updateStatus({ id: 1, status: "closed" });
    expect(result.success).toBe(true);
  });

  it("throws if flock belongs to different user", async () => {
    const { getFlockById } = await import("./db");
    vi.mocked(getFlockById).mockResolvedValueOnce({
      id: 99,
      userId: 999, // different user
      name: "Other Flock",
      breed: "ISA Brown",
      type: "layer",
      arrivalDate: new Date(),
      initialCount: 100,
      supplier: null,
      notes: null,
      status: "active",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.flock.get({ id: 99 })).rejects.toThrow("Flock not found");
  });
});

// ─── Daily Records Tests ───────────────────────────────────────────────────────
describe("dailyRecords router", () => {
  it("upserts a daily record with layer data", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.dailyRecords.upsert({
      flockId: 1,
      recordDate: "2025-04-01",
      mortality: 2,
      feedUsed: 50.5,
      eggsCollected: 450,
      brokenEggs: 5,
    });
    expect(result.success).toBe(true);
  });

  it("upserts a daily record with broiler weight data", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.dailyRecords.upsert({
      flockId: 1,
      recordDate: "2025-04-01",
      mortality: 1,
      feedUsed: 80.0,
      averageWeight: 1.250,
    });
    expect(result.success).toBe(true);
  });

  it("returns records by flock", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const records = await caller.dailyRecords.byFlock({ flockId: 1 });
    expect(Array.isArray(records)).toBe(true);
  });
});

// ─── Feed Tests ────────────────────────────────────────────────────────────────
describe("feed router", () => {
  it("records a feed purchase", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.feed.createPurchase({
      purchaseDate: "2025-04-01",
      feedType: "Layer Mash",
      quantityKg: 100,
      costPerKg: 0.50,
      supplier: "AgriSupply",
    });
    expect(result.success).toBe(true);
  });

  it("calculates FCR and cost per bird", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.feed.fcrAndCostPerBird({ flockId: 1 });
    // currentCount = 500 - 10 = 490, totalFeedUsed = 200
    // FCR = 200 / 490 ≈ 0.408
    expect(Number(result.fcr)).toBeCloseTo(200 / 490, 2);
    expect(result.currentCount).toBe(490);
  });
});

// ─── Expense Tests ─────────────────────────────────────────────────────────────
describe("expense router", () => {
  it("creates an expense record", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.expense.create({
      expenseDate: "2025-04-01",
      category: "medication",
      description: "Veterinary visit",
      amount: 150.00,
    });
    expect(result.success).toBe(true);
  });

  it("lists expenses for user", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const expenses = await caller.expense.list();
    expect(Array.isArray(expenses)).toBe(true);
  });

  it("returns expenses grouped by category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const byCategory = await caller.expense.byCategory();
    expect(Array.isArray(byCategory)).toBe(true);
  });
});

// ─── Sales Tests ───────────────────────────────────────────────────────────────
describe("sales router", () => {
  it("records an egg sale and calculates total revenue", async () => {
    const { createEggSale } = await import("./db");
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sales.createEggSale({
      flockId: 1,
      saleDate: "2025-04-01",
      quantity: 300,
      pricePerEgg: 0.15,
      buyer: "Local Market",
    });
    expect(result.success).toBe(true);
    // Verify totalRevenue was computed: 300 * 0.15 = 45
    expect(vi.mocked(createEggSale)).toHaveBeenCalledWith(
      expect.objectContaining({ totalRevenue: "45" })
    );
  });

  it("records a bird sale with average weight", async () => {
    const { createBirdSale } = await import("./db");
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sales.createBirdSale({
      flockId: 1,
      saleDate: "2025-04-01",
      quantity: 100,
      pricePerBird: 8.50,
      averageWeight: 2.1,
      buyer: "Wholesale",
    });
    expect(result.success).toBe(true);
    expect(vi.mocked(createBirdSale)).toHaveBeenCalledWith(
      expect.objectContaining({ totalRevenue: "850" })
    );
  });
});

// ─── Dashboard Tests ───────────────────────────────────────────────────────────
describe("dashboard router", () => {
  it("returns summary with correct profit/loss calculation", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const summary = await caller.dashboard.summary();
    expect(summary.activeFlocks).toBe(2);
    expect(summary.todayMortality).toBe(3);
    expect(summary.todayFeedUsed).toBe(45.5);
    // totalRevenue = 800 + 400 = 1200, totalExpenses = 1200, profitLoss = 0
    expect(summary.totalRevenue).toBe(1200);
    expect(summary.profitLoss).toBe(0);
  });
});

// ─── Reports Tests ─────────────────────────────────────────────────────────────
describe("reports router", () => {
  it("returns profit/loss summary", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const pl = await caller.reports.profitLoss();
    expect(pl.totalRevenue).toBe(1200);
    expect(pl.totalExpenses).toBe(1200);
    expect(pl.profitLoss).toBe(0);
    expect(pl.totalEggRevenue).toBe(800);
    expect(pl.totalBirdRevenue).toBe(400);
  });

  it("returns flock mortality rates", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const rates = await caller.reports.flockMortalityRates();
    expect(Array.isArray(rates)).toBe(true);
    expect(rates[0]?.mortalityRate).toBe(2); // 10/500 * 100 = 2%
  });

  it("returns feed usage per flock with FCR", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const usage = await caller.reports.feedUsagePerFlock();
    expect(Array.isArray(usage)).toBe(true);
    expect(usage[0]?.totalFeedUsed).toBe(200);
    expect(usage[0]?.fcr).toBeCloseTo(200 / 490, 2);
  });

  it("returns 30-day mortality trend", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const trend = await caller.reports.mortalityLast30Days();
    expect(Array.isArray(trend)).toBe(true);
  });
});

// ─── Role-Based Access Tests ───────────────────────────────────────────────────
describe("role-based access control", () => {
  it("farm_owner role is recognized correctly", async () => {
    const ctx = makeCtx("farm_owner");
    expect(ctx.user?.role).toBe("farm_owner");
  });

  it("manager role is recognized correctly", async () => {
    const ctx = makeCtx("manager");
    expect(ctx.user?.role).toBe("manager");
  });

  it("manager can list flocks (protected procedure)", async () => {
    const ctx = makeCtx("manager");
    const caller = appRouter.createCaller(ctx);
    const flocks = await caller.flock.list();
    expect(Array.isArray(flocks)).toBe(true);
  });

  it("manager can record daily entries", async () => {
    const ctx = makeCtx("manager");
    const caller = appRouter.createCaller(ctx);
    const result = await caller.dailyRecords.upsert({
      flockId: 1,
      recordDate: "2025-04-01",
      mortality: 0,
      feedUsed: 50,
    });
    expect(result.success).toBe(true);
  });
});
